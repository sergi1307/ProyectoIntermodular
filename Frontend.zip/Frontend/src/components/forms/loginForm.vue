<script setup>
    // Importem les llibreríes necessàries
    import { ref } from 'vue';
    import axios from 'axios';
    import { useRouter } from 'vue-router';
    import { useNotificaciones } from '@/utilidades/useNotificaciones';

    const router = useRouter();
    const notificacion = useNotificaciones();
    import url from '../../config/api';
    
    // Declarem les variables reactives que rebrem del formulari
    const email = ref('');
    const password = ref('');
    const recordarme = ref(false);

    // Definim un emit per a que quan apretem al botó ens canvie el component de loginForm a createAccount
    defineEmits(['cambiar-a-registro']);

    // Funció per a enviar les dades al backend
    const enviarDatos = async () => {

        // Si algún valor d'estos es null que done una alerta per a que els plene tots
        if (!email.value || !password.value) {
            notificacion.advertencia("Por favor, rellena todos los campos.");
            return;
        }

        // Muntem el JSON per a enviar-lo al backend en la estructura correcta
        const datos = {
            email: email.value,
            password: password.value
        };

        console.log("Enviando datos al backend:", datos);

        try {
            // Fem la petició axios al backend enviant les dades necessàries per a fer el login
            const response = await axios.post(`${url}/api/auth/login`, datos, {
                withCredentials: true
            });

            console.log("Respuesta del servidor:", response.data);

            if (response.data.status == 'true') {
                localStorage.setItem('token', response.data.token);

                if(response.data.user) {
                    localStorage.setItem('user', JSON.stringify(response.data.user));
                    console.log("Usuari guardat en LocalStorage:", response.data.user);
                } else {
                    console.warn("El backend no ha tornat l'usuari");
                }
                notificacion.exito("¡Bienvenido de nuevo!");
                router.push('/general');
            }
        } catch (error) {
            if (error.response) {
                // El servidor respondió con error
                notificacion.error(error.response.data.message || 'Error de autenticación');
            } else if (error.request) {
                // La petición se hizo pero no hubo respuesta (CORS/servidor apagado)
                notificacion.error('No se pudo conectar con el servidor. Verifica que el backend esté encendido y CORS configurado.');
            } else {
                // Error al configurar la petición
                notificacion.error('Error: ' + error.message);
            }
        }
    }
</script>

<template>
    <div class="form-container">
        <h2>Bienvenido de Nuevo</h2>
        <p>Inicia sesión para entrar a Proximarkt</p>
        <!-- Cuan apretem al botó de submit, captura el procés HTML per a que faja la petició de Axios -->
        <form @submit.prevent="enviarDatos">
            <label for="email">Correo Electrónico</label>
            <input type="email" placeholder="ejemplo@ejemplo.com" v-model="email"> 

            <label for="password">Contraseña</label>
            <input type="password" placeholder="••••••••" v-model="password">

            <div id="remember_forgot">
                <div>
                    <input type="checkbox" v-model="recordarme">Remember me
                </div>
                <button>Ha olvidado la contraseña?</button>
            </div>

            <button type="submit">Iniciar Sesión</button>

            <!-- Si apreten a este botó canvia el component de Login a Register -->
            <p>No tienes una cuenta aún? <a href="#" @click.prevent="$emit('cambiar-a-registro')">Crear Cuenta</a></p>
        </form>
    </div>
</template>

<style scoped>
    .form-container {
        width: 100%;
        max-width: 450px;
        margin: 0 auto;
        padding: 20px;
        box-sizing: border-box;
        color: #333;
    }

    h2 {
        color: #1c5537;
        font-weight: bold;
        font-size: 1.8rem;
        margin-bottom: 5px;
    }

    p {
        color: #666;
        margin-bottom: 30px;
        font-size: 0.95rem;
    }

    form {
        display: flex;
        flex-direction: column;
        gap: 20px;
    }

    label {
        font-weight: 500;
        font-size: 0.9rem;
        color: #555;
        display: inline-block;
    }

    input[type="email"],
    input[type="password"] {
        width: 100%;
        padding: 12px 15px;
        border: 1px solid #ddd;
        border-radius: 8px;
        font-size: 1rem;
        box-sizing: border-box;
        transition: border-color 0.3s;
    }

    input:focus {
        outline: none;
        border-color: #1c5537;
    }

    #remember_forgot {
        display: flex;
        justify-content: space-between;
        align-items: center;
        font-size: 0.8rem;
        color: #555;
    }
    
    #remember_forgot div {
        display: flex;
        align-items: center;
    }

    #remember_forgot input[type="checkbox"] {
        accent-color: #1c5537;
        margin-right: 5px;
        width: auto;
    }

    #remember_forgot button {
        background: none;
        border: none;
        color: #1c5537;
        cursor: pointer;
        font-weight: 600;
        padding: 0;
        font-size: 1em;
    }

    button[type="submit"] {
        background-color: #1c5537;
        color: white;
        padding: 18px;
        border: none;
        border-radius: 8px;
        font-size: 1rem;
        font-weight: bold;
        cursor: pointer;
        width: 100%;
        transition: background-color 0.3s;
        margin-bottom: 10px;
    }

    button[type="submit"]:hover {
        background-color: #14402a;
    }

    .form-container > form > p:last-child {
        text-align: center;
        margin-bottom: 0;
    }

    a {
        color: #1c5537;
        font-weight: bold;
        text-decoration: none;
    }

    @media (max-width: 600px) {
        .form-container {
            max-width: 100%;
            padding: 15px;
        }

        h2 {
            font-size: 1.5rem;
        }

        input[type="email"],
        input[type="password"] {
            font-size: 16px;
            padding: 14px 15px;
        }

        button[type="submit"] {
            padding: 15px;
        }

        #remember_forgot {
            flex-direction: column;
            gap: 10px;
            align-items: flex-start;
        }
    }
</style>