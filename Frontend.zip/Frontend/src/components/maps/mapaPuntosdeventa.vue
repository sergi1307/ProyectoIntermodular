<template>
    <div class="contenedor-mapa tarjeta-mapa">
      <h3>{{ titulo }}</h3>
      <div :id="mapId"></div>
    </div>
  </template>
  
  <script>
  import L from 'leaflet';
  import 'leaflet/dist/leaflet.css';
  import icon from 'leaflet/dist/images/marker-icon.png';
  import iconShadow from 'leaflet/dist/images/marker-shadow.png';
  
  let DefaultIcon = L.icon({
      iconUrl: icon, shadowUrl: iconShadow,
      iconSize: [25, 41], iconAnchor: [12, 41]
  });
  L.Marker.prototype.options.icon = DefaultIcon;
  
  /**
   * Componente para mostrar el mapa interactivo con marcadores de puntos de venta
   */
  export default {
      name: 'MapaTiendas',
      props: {
          puntos: { type: Array, required: true },
          titulo: { type: String, default: 'Mapa' },
          esSeleccionable: { type: Boolean, default: false },
          esEditable: { type: Boolean, default: false },
          mapId: { type: String, default: 'mapa-leaflet' }
      },
      data() {
          return {
              map: null,       
              layerGroup: null,
              marcadorTemporal: null
          }
      },
      mounted() {
          this.iniciarMapa();
      },
      watch: {
          puntos: {
              handler(newVal) {
                  if (this.map) {
                      this.map.closePopup(); // Cerrar cualquier popup abierto al cambiar filtros
                      this.dibujarMarcadores();
                  }
              },
              deep: true
          }
      },
      beforeUnmount() {
          if (this.map) {
              this.map.remove();
          }
      },
      methods: {
        // Inicializa el mapa con límites de España
        iniciarMapa() {
            var surOeste = L.latLng(33.0, -12.0); 
            var norteEste = L.latLng(45.0, 6.0);
            var limitesEspaña = L.latLngBounds(surOeste, norteEste);

            this.map = L.map(this.mapId, {
                center: [40.4167, -3.70325],
                zoom: 6,
                minZoom: 5,
                maxZoom: 18,
                maxBounds: limitesEspaña,
        });
        
        L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; OpenStreetMap'
        }).addTo(this.map);

            this.layerGroup = L.layerGroup().addTo(this.map);

            // Click en el mapa para añadir nuevo punto (solo si es editable)
            if (this.esEditable) {
                this.map.on('click', (e) => {
                    // Eliminar marcador temporal anterior si existe
                    if (this.marcadorTemporal) {
                        this.map.removeLayer(this.marcadorTemporal);
                    }
                    
                    // Crear nuevo marcador temporal con color distintivo
                    const iconoTemporal = L.icon({
                        iconUrl: icon,
                        shadowUrl: iconShadow,
                        iconSize: [25, 41],
                        iconAnchor: [12, 41],
                        className: 'marcador-nuevo'
                    });
                    
                    this.marcadorTemporal = L.marker([e.latlng.lat, e.latlng.lng], { icon: iconoTemporal })
                        .addTo(this.map);
                    
                    // Emitir coordenadas para abrir el formulario
                    this.$emit('mapa-clickeado', {
                        latitude: e.latlng.lat,
                        length: e.latlng.lng
                    });
                });
            }

            // Dibujar marcadores si existen
            if (this.puntos && this.puntos.length > 0) {
                this.dibujarMarcadores();
            }
        },
          // Dibuja marcadores en el mapa y ajusta zoom
          dibujarMarcadores() {
              this.layerGroup.clearLayers();
              const limites = [];
              this.puntos.forEach(punto => {
                  const lat = punto.latitude;
                  const lng = punto['length']; // Usar bracket notation porque 'length' es palabra reservada 

                  if (lat && lng) {
                      const marcador = L.marker([lat, lng]);
                      
                      if (this.esSeleccionable) {
                          marcador.bindPopup(`<b>${punto.name}</b><br>Click para seleccionar`);
                          marcador.on('click', () => {
                              this.$emit('tienda-elegida', punto.id);
                              marcador.openPopup();
                          });
                      } else if (!this.esEditable) {
                          // Modo visualización: solo emitir evento sin popup
                          marcador.on('click', () => {
                              this.$emit('punto-seleccionado', punto);
                          });
                      } else {
                          marcador.bindPopup(`<b>${punto.name}</b><br>${punto.direction}`);
                      }
  
                      this.layerGroup.addLayer(marcador);
                      
                      limites.push([lat, lng]);
                  }
              });
              if (limites.length > 0) {
                  this.map.fitBounds(limites, { padding: [50, 50], maxZoom: 8 });
              }
          }
      }
  }
  </script>
  

<style scoped>
.tarjeta-mapa {
    width: 100%;
    max-width: 1400px;
    margin: 0 auto;
    background: white;
    padding: 15px;
    border-radius: 20px;
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
    text-align: center;
    box-sizing: border-box;
}

h3 {
    margin-top: 0;
    margin-bottom: 15px;
    color: #333;
}

.tarjeta-mapa > div:nth-child(2) {
    width: 100%;
    height: 450px;
    border-radius: 15px;
    border: 2px solid #eee;
    z-index: 1;
}

.error {
    color: grey;
    font-style: italic;
    padding: 10px;
}

.marcador-nuevo {
    filter: hue-rotate(100deg) brightness(1.3);
}

@media (max-width: 768px) {
    .tarjeta-mapa {
        padding: 10px;
        border-radius: 12px;
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
    }

    .tarjeta-mapa > div:nth-child(2) {
        height: 300px; 
        border-radius: 10px;
    }

    h3 {
        font-size: 1.2rem;
        margin-bottom: 10px;
    }
}
</style>